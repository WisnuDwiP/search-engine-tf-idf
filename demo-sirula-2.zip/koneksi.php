<?php 
    $konek = mysqli_connect("localhost","root","","db_sirula");
 ?>